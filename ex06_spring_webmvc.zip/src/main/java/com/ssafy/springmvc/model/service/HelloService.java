package com.ssafy.springmvc.model.service;

import com.ssafy.springmvc.model.HelloDto;

public interface HelloService {
	
	HelloDto greeting();
}
