package aop04;

public interface Person {
	public void work();
}
