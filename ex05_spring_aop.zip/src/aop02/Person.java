package aop02;

public interface Person {
	public void work();
}
