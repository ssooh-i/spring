package test2;

public class Animal {
	String animal;

	public Animal(String str) {
		setAnimal(str);
	}
	
	public String getAnimal() {
		return animal;
	}

	public void setAnimal(String animal) {
		this.animal = animal;
	}
}
