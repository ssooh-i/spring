package aop05;

public interface Person {
	public void work();
}
