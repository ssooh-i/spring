package com.ssafy.springmvc.model.dao;

public interface HelloDao {
	String greeting();
}
