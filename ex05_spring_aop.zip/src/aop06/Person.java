package aop06;

public interface Person {
	public void work();
}
