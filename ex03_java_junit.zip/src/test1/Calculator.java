package test1;

public class Calculator {      // abc         def   ===> abcdef    
	public String concatenate(String a, String b) {
		return a+b;
	}
	
	public int add(int x, int y) {
		return x+y;
	}
	
	public int subtract(int x, int y) {
		return x-y;
	}
}
