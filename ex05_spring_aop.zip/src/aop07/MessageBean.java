package aop07;

public interface MessageBean {
	public void sayHello();
}
