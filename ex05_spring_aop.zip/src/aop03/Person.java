package aop03;

public interface Person {
	public void work();
}
